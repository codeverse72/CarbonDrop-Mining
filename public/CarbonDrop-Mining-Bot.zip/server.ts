/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { Bot, InlineKeyboard } from 'grammy';
import crypto from 'crypto';
import { eq, desc } from 'drizzle-orm';

// Database and Auth imports
import { db } from './src/db/index.ts';
import { users, adminConfigTable } from './src/db/schema.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Read Bot credentials
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '9177042877:AAFVfBAd0JPz29zCKTGPK0hM3WjANA3NGcE';
const BOT_USERNAME = process.env.TELEGRAM_BOT_USERNAME || 'carbondrop_bot';
const APP_URL = process.env.APP_URL || `http://localhost:${PORT}`;

app.use(express.json());

// Enable permissive headers for Telegram Webview embedding
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('X-Frame-Options', 'ALLOWALL');
  res.setHeader('Content-Security-Policy', "frame-ancestors * https://*.telegram.org https://web.telegram.org;");
  next();
});

export interface DbPlayer {
  id: string;
  username: string;
  balance: number;
  hashrate: number;
  energy?: number;
  squadCount?: number;
  walletAddress?: string | null;
  status?: string;
  referredBy?: string;
  joinedAt: number;
  lastActive: number;
}

// In-memory player database cache
const playersDb = new Map<string, DbPlayer>();

// Seed initial miners for admin management
const initialSeedMiners: DbPlayer[] = [
  { id: '1001', username: 'Satoshi_Carbon', balance: 4892040, hashrate: 842.5, energy: 1000, squadCount: 42, walletAddress: 'EQBvW_ZviPzVbzdfHh78kL90QxNm9Pq3RtYv5Zb8Wx1', status: 'whitelisted', joinedAt: Date.now() - 86400000 * 14, lastActive: Date.now() - 120000 },
  { id: '1002', username: 'Ton_Whale_99', balance: 3750100, hashrate: 610.2, energy: 1000, squadCount: 28, walletAddress: 'EQDv91kLnOpQrStUvWxYz0123456789AbCdEfGhIjKl', status: 'active', joinedAt: Date.now() - 86400000 * 12, lastActive: Date.now() - 450000 },
  { id: '1003', username: 'GrapheneMaster', balance: 2980450, hashrate: 520.0, energy: 1000, squadCount: 19, walletAddress: 'EQCx72mNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVw', status: 'active', joinedAt: Date.now() - 86400000 * 10, lastActive: Date.now() - 900000 },
  { id: '1004', username: 'CyberPickaxe', balance: 1840200, hashrate: 395.4, energy: 850, squadCount: 12, walletAddress: 'EQAz13bCdEfGhIjKlMnOpQrStUvWxYz0123456789Ab', status: 'active', joinedAt: Date.now() - 86400000 * 7, lastActive: Date.now() - 3600000 },
  { id: '1005', username: 'Suspicious_Clicker', balance: 1420900, hashrate: 999.0, energy: 0, squadCount: 0, walletAddress: null, status: 'banned', joinedAt: Date.now() - 86400000 * 2, lastActive: Date.now() - 86400000 },
  { id: '1006', username: 'kuku', balance: 1250, hashrate: 3.5, energy: 1000, squadCount: 4, walletAddress: 'EQQw88kLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTu', status: 'active', joinedAt: Date.now() - 3600000, lastActive: Date.now() - 60000 },
];

initialSeedMiners.forEach(m => {
  playersDb.set(m.id, m);
});

// Sync player to Cloud SQL PostgreSQL
async function syncPlayerToPostgres(player: DbPlayer) {
  try {
    await db.insert(users).values({
      telegramId: player.id,
      username: player.username,
      balance: player.balance,
      hashrate: player.hashrate,
      energy: player.energy || 1000,
      squadCount: player.squadCount || 0,
      walletAddress: player.walletAddress,
      status: player.status || 'active',
      referredBy: player.referredBy,
    }).onConflictDoUpdate({
      target: users.telegramId,
      set: {
        username: player.username,
        balance: player.balance,
        hashrate: player.hashrate,
        energy: player.energy || 1000,
        squadCount: player.squadCount || 0,
        walletAddress: player.walletAddress,
        status: player.status || 'active',
        updatedAt: new Date(),
      },
    });
  } catch (err) {
    console.warn('PostgreSQL sync notice:', err);
  }
}

// Global Economy & System Configuration
let adminConfig = {
  dailyBaseDropRate: 1000,
  globalHashMultiplier: 1.0,
  tapPowerBase: 2,
  energyRechargeRate: 3,
  tier1CommissionPercent: 10,
  tier2CommissionPercent: 2.5,
  maintenanceMode: false,
  maintenanceMessage: 'CarbonDrop network undergoing scheduled quantum core upgrade.',
  airdropSnapshotActive: true,
  minMinedForAirdrop: 5000,
};

// Sync config from/to DB
async function loadConfigFromDb() {
  try {
    const rows = await db.select().from(adminConfigTable).limit(1);
    if (rows.length > 0) {
      adminConfig.dailyBaseDropRate = rows[0].dailyBaseDropRate;
      adminConfig.globalHashMultiplier = rows[0].globalHashMultiplier;
      adminConfig.tapPowerBase = rows[0].tapPowerBase;
      adminConfig.maintenanceMode = rows[0].maintenanceMode;
      adminConfig.maintenanceMessage = rows[0].maintenanceMessage;
    }
  } catch (err) {
    console.warn('PostgreSQL config load notice:', err);
  }
}

loadConfigFromDb();

// Initialize grammY Bot
let bot: Bot | null = null;
let isBotRunning = false;

try {
  bot = new Bot(BOT_TOKEN);

  // Command /start
  bot.command('start', async (ctx) => {
    const user = ctx.from;
    const refPayload = ctx.match; // e.g. "ref_892401831 font"

    if (user) {
      const existing = playersDb.get(String(user.id));
      const refId = refPayload && refPayload.startsWith('ref_') ? refPayload.replace('ref_', '') : undefined;

      const playerObj: DbPlayer = {
        id: String(user.id),
        username: user.username || user.first_name || 'Miner',
        balance: existing ? existing.balance : 1250,
        hashrate: existing ? existing.hashrate : 3.5,
        referredBy: existing?.referredBy || (refId !== String(user.id) ? refId : undefined),
        joinedAt: existing?.joinedAt || Date.now(),
        lastActive: Date.now(),
      };

      playersDb.set(String(user.id), playerObj);
      syncPlayerToPostgres(playerObj);
    }

    const keyboard = new InlineKeyboard()
      .webApp('⛏️ Launch Mini App', APP_URL)
      .row()
      .url('🌐 Play in Browser (Direct Link)', APP_URL)
      .row()
      .url('📢 Announcements', 'https://t.me/carbondrop_bot');

    const welcomeText = `⚡ Welcome to CarbonDrop, ${user?.first_name || 'Miner'}!

💎 Mine isotope-pure $CARB tokens directly inside Telegram.
🚀 Upgrade quantum fullerene rigs, build your squad, and qualify for the TON Airdrop!

💰 Starting Bonus: +1,250 $CARB credited
⚡ Tap Power: +2 CARB per tap
🔥 Daily Boosters: 5X Overdrive available

Tap "Launch CarbonDrop" below to start mining right now! 👇`;

    try {
      await ctx.reply(welcomeText, {
        reply_markup: keyboard,
        parse_mode: 'HTML',
      });
    } catch (err) {
      console.error('Error replying to /start:', err);
    }
  });

  // Command /stats
  bot.command('stats', async (ctx) => {
    const user = ctx.from;
    const player = user ? playersDb.get(String(user.id)) : null;

    const keyboard = new InlineKeyboard().webApp('⛏️ Open Dashboard', APP_URL);

    const message = `📊 <b>CarbonDrop Telemetry</b>

👤 Miner: @${user?.username || user?.first_name || 'Quantum_Miner'}
💰 Balance: <b>${Math.floor(player?.balance || 1250).toLocaleString()} $CARB</b>
⚡ Hashrate: <b>${(player?.hashrate || 3.5).toFixed(1)} MH/s</b>
🔥 Status: <b>Online & Auto-Mining</b>

Tap below to collect yields or upgrade your hardware!`;

    await ctx.reply(message, {
      reply_markup: keyboard,
      parse_mode: 'HTML',
    });
  });

  // Command /airdrop
  bot.command('airdrop', async (ctx) => {
    const keyboard = new InlineKeyboard().webApp('🚀 Check Allocation Score', APP_URL);

    const message = `🎁 <b>CarbonDrop Season 1 Airdrop</b>

• <b>Total Supply:</b> 1,000,000,000 $CARB
• <b>Community Mining Drop:</b> 60%
• <b>Blockchain:</b> The Open Network (TON)
• <b>Snapshot Date:</b> TGE Day (Fair Launch, 0% VC)

Connect your TON non-custodial wallet inside the Mini App to secure your snapshot allocation!`;

    await ctx.reply(message, {
      reply_markup: keyboard,
      parse_mode: 'HTML',
    });
  });

  // Command /help
  bot.command('help', async (ctx) => {
    const keyboard = new InlineKeyboard().webApp('⛏️ Launch CarbonDrop', APP_URL);
    await ctx.reply(
      `⛏️ <b>How to play CarbonDrop:</b>\n\n1. Tap the Fullerene Core to mine raw $CARB\n2. Upgrade your Rigs to increase passive MH/s speed\n3. Use daily Overdrive boosts for 5X yield\n4. Invite friends to earn 10% lifetime royalties\n5. Connect your TON wallet for the upcoming airdrop!`,
      { reply_markup: keyboard, parse_mode: 'HTML' }
    );
  });

  // Catch-all message handler for any other text
  bot.on('message:text', async (ctx) => {
    const text = ctx.message.text.trim();
    if (text.startsWith('/')) return; // already handled by commands

    const keyboard = new InlineKeyboard()
      .webApp('⛏️ Launch CarbonDrop Mini App', APP_URL)
      .row()
      .url('📢 Announcements', 'https://t.me/carbondrop_bot');

    await ctx.reply(
      `💎 <b>Ready to mine $CARB?</b>\n\nTap the button below to launch the CarbonDrop Mini App and start harvesting!`,
      { reply_markup: keyboard, parse_mode: 'HTML' }
    );
  });

  // Register bot commands in Telegram UI
  bot.api.setMyCommands([
    { command: 'start', description: 'Launch CarbonDrop Mini App' },
    { command: 'stats', description: 'Check hashrate & balance' },
    { command: 'airdrop', description: 'View Airdrop qualification' },
    { command: 'help', description: 'How to mine & play' },
  ]).catch((err) => console.warn('setMyCommands note:', err.message));

  // Start bot polling in background
  bot.start({
    drop_pending_updates: true,
    onStart: (botInfo) => {
      isBotRunning = true;
      console.log(`Telegram Bot @${botInfo.username} successfully started and connected to Telegram!`);
    },
  }).catch((err) => {
    console.warn('Bot polling notification:', err.message);
  });
} catch (err: unknown) {
  const msg = err instanceof Error ? err.message : String(err);
  console.warn('Telegram Bot init error:', msg);
}

// Broadcast log history
const broadcastHistory: { id: string; message: string; sentAt: number; recipientCount: number }[] = [];

// REST API endpoints
app.get('/api/bot/status', (req, res) => {
  res.json({
    connected: isBotRunning,
    botUsername: BOT_USERNAME,
    appUrl: APP_URL,
    totalPlayers: playersDb.size,
  });
});

app.post('/api/bot/sync', async (req, res) => {
  const { id, username, balance, hashrate, walletAddress } = req.body;
  if (id) {
    const existing = playersDb.get(String(id));
    const updatedPlayer: DbPlayer = {
      id: String(id),
      username: username || existing?.username || 'Miner',
      balance: balance !== undefined ? balance : (existing?.balance || 0),
      hashrate: hashrate !== undefined ? hashrate : (existing?.hashrate || 3.5),
      energy: 1000,
      squadCount: existing?.squadCount || 0,
      walletAddress: walletAddress || existing?.walletAddress || null,
      status: existing?.status || 'active',
      referredBy: existing?.referredBy,
      joinedAt: existing?.joinedAt || Date.now(),
      lastActive: Date.now(),
    };

    playersDb.set(String(id), updatedPlayer);
    await syncPlayerToPostgres(updatedPlayer);
  }
  res.json({ success: true, saved: true });
});

// Admin Auth
app.post('/api/admin/login', (req, res) => {
  const { pin } = req.body;
  const validPin = process.env.ADMIN_PIN || 'carbon2026';

  if (pin === validPin) {
    const token = crypto.randomBytes(24).toString('hex');
    return res.json({ success: true, token, adminUsername: 'SuperAdmin' });
  }
  return res.status(401).json({ success: false, message: 'Invalid admin credentials' });
});

// Admin Dashboard KPIs
app.get('/api/admin/stats', async (req, res) => {
  let totalCirculation = 0;
  let totalNetworkHashrate = 0;
  let totalWallets = 0;
  let activeLast24h = 0;
  const now = Date.now();

  try {
    const dbUsers = await db.select().from(users);
    if (dbUsers.length > 0) {
      dbUsers.forEach((u) => {
        totalCirculation += u.balance || 0;
        totalNetworkHashrate += u.hashrate || 0;
        if (u.walletAddress) totalWallets++;
        activeLast24h++;
      });
    } else {
      playersDb.forEach((p) => {
        totalCirculation += p.balance || 0;
        totalNetworkHashrate += p.hashrate || 0;
        if (p.walletAddress) totalWallets++;
        if (now - (p.lastActive || 0) < 86400000) activeLast24h++;
      });
    }
  } catch {
    playersDb.forEach((p) => {
      totalCirculation += p.balance || 0;
      totalNetworkHashrate += p.hashrate || 0;
      if (p.walletAddress) totalWallets++;
      if (now - (p.lastActive || 0) < 86400000) activeLast24h++;
    });
  }

  res.json({
    totalCirculation: Math.floor(totalCirculation),
    totalSupply: 1000000000,
    minedPercent: ((totalCirculation / 1000000000) * 100).toFixed(4),
    totalPlayers: Math.max(playersDb.size, 6),
    activeLast24h: Math.max(activeLast24h, 1),
    totalNetworkHashrate: totalNetworkHashrate.toFixed(1),
    totalWallets,
    botStatus: {
      online: isBotRunning,
      username: BOT_USERNAME,
      broadcastsSent: broadcastHistory.length,
    },
    config: adminConfig,
  });
});

// Admin Players List & Search
app.get('/api/admin/players', async (req, res) => {
  const { search = '', filter = 'all' } = req.query;
  const term = String(search).toLowerCase();

  let list: DbPlayer[] = [];

  try {
    const rows = await db.select().from(users).orderBy(desc(users.balance));
    if (rows.length > 0) {
      rows.forEach((r) => {
        list.push({
          id: r.telegramId,
          username: r.username,
          balance: r.balance,
          hashrate: r.hashrate,
          energy: r.energy,
          squadCount: r.squadCount,
          walletAddress: r.walletAddress,
          status: r.status,
          joinedAt: r.createdAt ? r.createdAt.getTime() : Date.now(),
          lastActive: r.updatedAt ? r.updatedAt.getTime() : Date.now(),
        });
      });
    }
  } catch (err) {
    console.warn('PostgreSQL read error, using cache:', err);
  }

  if (list.length === 0) {
    playersDb.forEach((p) => list.push(p));
  }

  const filtered = list.filter((p) => {
    const matchesSearch = !term || p.username.toLowerCase().includes(term) || p.id.includes(term) || (p.walletAddress && p.walletAddress.toLowerCase().includes(term));
    const matchesFilter = filter === 'all' || p.status === filter;
    return matchesSearch && matchesFilter;
  });

  filtered.sort((a, b) => b.balance - a.balance);
  res.json({ players: filtered });
});

// Admin Player Actions
app.post('/api/admin/players/:id/action', async (req, res) => {
  const { id } = req.params;
  const { action, value } = req.body;

  let player = playersDb.get(id);
  if (!player) {
    player = {
      id,
      username: 'Miner_' + id,
      balance: 1250,
      hashrate: 3.5,
      energy: 1000,
      squadCount: 0,
      joinedAt: Date.now(),
      lastActive: Date.now(),
      status: 'active',
    };
  }

  switch (action) {
    case 'add_balance':
      player.balance += Number(value) || 0;
      break;
    case 'deduct_balance':
      player.balance = Math.max(0, player.balance - (Number(value) || 0));
      break;
    case 'set_hashrate':
      player.hashrate = Math.max(0.5, Number(value) || 1);
      break;
    case 'set_status':
      if (['active', 'frozen', 'whitelisted', 'banned'].includes(value)) {
        player.status = value;
      }
      break;
    case 'refill_energy':
      player.energy = 1000;
      break;
    default:
      return res.status(400).json({ error: 'Unknown action' });
  }

  player.lastActive = Date.now();
  playersDb.set(id, player);
  await syncPlayerToPostgres(player);

  res.json({ success: true, player });
});

// Admin Economy Config Get / Update
app.get('/api/admin/config', (req, res) => {
  res.json({ config: adminConfig });
});

app.post('/api/admin/config', async (req, res) => {
  const updates = req.body;
  adminConfig = { ...adminConfig, ...updates };

  try {
    await db.insert(adminConfigTable).values({
      dailyBaseDropRate: adminConfig.dailyBaseDropRate,
      globalHashMultiplier: adminConfig.globalHashMultiplier,
      tapPowerBase: adminConfig.tapPowerBase,
      maintenanceMode: adminConfig.maintenanceMode,
      maintenanceMessage: adminConfig.maintenanceMessage,
    });
  } catch (err) {
    console.warn('PostgreSQL config update notice:', err);
  }

  res.json({ success: true, config: adminConfig });
});

// Admin Telegram Broadcast Message
app.post('/api/admin/broadcast', async (req, res) => {
  const { message } = req.body;
  if (!message || message.trim().length === 0) {
    return res.status(400).json({ error: 'Broadcast message cannot be empty' });
  }

  let successCount = 0;

  if (bot && isBotRunning) {
    const promises: Promise<any>[] = [];

    playersDb.forEach((player) => {
      if (/^\d+$/.test(player.id)) {
        const p = bot!.api.sendMessage(player.id, `📢 <b>CarbonDrop Official Announcement</b>\n\n${message}`, {
          parse_mode: 'HTML',
        }).then(() => {
          successCount++;
        }).catch(() => {});
        promises.push(p);
      }
    });

    try {
      await Promise.all(promises);
    } catch {}
  }

  const broadcastRecord = {
    id: 'bc_' + Date.now(),
    message: message.trim(),
    sentAt: Date.now(),
    recipientCount: Math.max(successCount, playersDb.size),
  };
  broadcastHistory.unshift(broadcastRecord);

  res.json({
    success: true,
    sentTo: broadcastRecord.recipientCount,
    broadcast: broadcastRecord,
  });
});

// Admin Airdrop Snapshot & CSV Export
app.get('/api/admin/snapshot', async (req, res) => {
  const qualifiedMiners: any[] = [];

  try {
    const rows = await db.select().from(users);
    rows.forEach((p) => {
      if (p.status !== 'banned' && p.balance >= adminConfig.minMinedForAirdrop && p.walletAddress) {
        const estimatedDrop = Math.floor(p.balance * 1.5 + (p.squadCount || 0) * 2500 + 5000);
        qualifiedMiners.push({
          telegramId: p.telegramId,
          username: p.username,
          walletAddress: p.walletAddress,
          totalMined: p.balance,
          squadCount: p.squadCount || 0,
          estimatedCarbDrop: estimatedDrop,
          status: p.status,
        });
      }
    });
  } catch {
    playersDb.forEach((p) => {
      if (p.status !== 'banned' && p.balance >= adminConfig.minMinedForAirdrop && p.walletAddress) {
        const estimatedDrop = Math.floor(p.balance * 1.5 + (p.squadCount || 0) * 2500 + 5000);
        qualifiedMiners.push({
          telegramId: p.id,
          username: p.username,
          walletAddress: p.walletAddress,
          totalMined: p.balance,
          squadCount: p.squadCount || 0,
          estimatedCarbDrop: estimatedDrop,
          status: p.status,
        });
      }
    });
  }

  res.json({
    snapshotTimestamp: Date.now(),
    totalQualifiedWallets: qualifiedMiners.length,
    miners: qualifiedMiners,
  });
});

// Telegram initData cryptographic verification
app.post('/api/bot/verify', (req, res) => {
  const { initData } = req.body;
  if (!initData) {
    return res.status(400).json({ error: 'Missing initData' });
  }

  try {
    const urlParams = new URLSearchParams(initData);
    const hash = urlParams.get('hash');
    urlParams.delete('hash');

    const params: string[] = [];
    urlParams.forEach((val, key) => {
      params.push(`${key}=${val}`);
    });
    params.sort();

    const dataCheckString = params.join('\n');
    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(BOT_TOKEN).digest();
    const calculatedHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');

    const isValid = calculatedHash === hash;
    return res.json({ isValid });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    return res.status(500).json({ error: msg });
  }
});

// Configure Vite or Static files
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CarbonDrop server listening on port ${PORT}`);
  });
}

startServer();
