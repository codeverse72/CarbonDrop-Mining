/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Pickaxe, Flame, Award, Users, Trophy } from 'lucide-react';

export type NavTab = 'mine' | 'boost' | 'quests' | 'squad' | 'ranks';

interface BottomNavProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  unclaimedQuestsCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  unclaimedQuestsCount,
}) => {
  const tabs: { id: NavTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'boost', label: 'Boost', icon: <Flame className="w-5 h-5" /> },
    { id: 'quests', label: 'Quests', icon: <Award className="w-5 h-5" />, badge: unclaimedQuestsCount },
    { id: 'mine', label: 'Carbs', icon: <Pickaxe className="w-5 h-5" /> },
    { id: 'squad', label: 'Squad', icon: <Users className="w-5 h-5" /> },
    { id: 'ranks', label: 'Ranks', icon: <Trophy className="w-5 h-5" /> },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0d091b]/95 backdrop-blur-lg border-t border-purple-900/40 px-3 py-1 max-w-lg mx-auto sm:max-w-xl">
      <div className="grid grid-cols-5 items-center h-14">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex flex-col items-center justify-center h-full min-h-[44px] min-w-[44px] relative rounded-xl transition-all ${
                isActive
                  ? 'text-purple-300 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {/* Active ambient glow pill */}
              {isActive && (
                <div className="absolute inset-x-2 inset-y-1 bg-purple-600/20 rounded-xl -z-10 border border-purple-500/30" />
              )}

              <div className="relative">
                {tab.icon}
                {tab.badge && tab.badge > 0 ? (
                  <span className="absolute -top-1 -right-2 w-3.5 h-3.5 rounded-full bg-amber-500 text-slate-950 font-black text-[9px] flex items-center justify-center font-mono animate-pulse">
                    {tab.badge}
                  </span>
                ) : null}
              </div>

              <span
                className={`text-[11px] mt-0.5 tracking-tight transition-colors ${
                  isActive ? 'text-white font-bold' : 'text-slate-400'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
