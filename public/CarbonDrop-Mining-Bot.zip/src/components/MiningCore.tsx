/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Coins, Sparkles, CheckCircle2, Flame, TrendingUp } from 'lucide-react';
import confetti from 'canvas-confetti';
import { UserStats } from '../types';
import { MINING_PLANS } from '../data/mockData';
import { sound } from '../utils/sound';

interface MiningCoreProps {
  stats: UserStats;
  baseDropRate: number; // Configured by admin (default: 1000)
  onClaimDailyDrop: (amount: number) => void;
  onOpenWallet: () => void;
}

export const MiningCore: React.FC<MiningCoreProps> = ({
  stats,
  baseDropRate = 1000,
  onClaimDailyDrop,
}) => {
  const [corePress, setCorePress] = useState(false);

  // Time calculation for once-a-day drop (24 hours cooldown = 86,400,000 ms)
  const COOLDOWN_MS = 24 * 60 * 60 * 1000;
  const now = Date.now();
  const lastClaim = stats.lastDailyClaimTimestamp || 0;
  const timeSinceLastClaim = now - lastClaim;
  const isClaimReady = timeSinceLastClaim >= COOLDOWN_MS;

  const msRemaining = Math.max(0, COOLDOWN_MS - timeSinceLastClaim);

  const [timeLeft, setTimeLeft] = useState({
    hours: Math.floor(msRemaining / (1000 * 60 * 60)),
    minutes: Math.floor((msRemaining % (1000 * 60 * 60)) / (1000 * 60)),
    seconds: Math.floor((msRemaining % (1000 * 60)) / 1000),
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const currentNow = Date.now();
      const currentRemaining = Math.max(0, COOLDOWN_MS - (currentNow - (stats.lastDailyClaimTimestamp || 0)));
      setTimeLeft({
        hours: Math.floor(currentRemaining / (1000 * 60 * 60)),
        minutes: Math.floor((currentRemaining % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((currentRemaining % (1000 * 60)) / 1000),
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [stats.lastDailyClaimTimestamp]);

  // Calculate current active plan daily bonus
  const activePlan = MINING_PLANS.find((p) => p.id === stats.activePlanId);
  const planDailyBonus = activePlan ? activePlan.dailyTokens : 0;
  const totalDailyDropAmount = baseDropRate + planDailyBonus;

  // Calculate tokens generated so far & current generation rate
  const elapsedRatio = Math.min(1, Math.max(0, timeSinceLastClaim / COOLDOWN_MS));
  const tokensGeneratedSoFar = Math.floor(totalDailyDropAmount * elapsedRatio);
  const tokensPerHour = (totalDailyDropAmount / 24).toFixed(1);
  const tokensPerSecond = (totalDailyDropAmount / 86400).toFixed(4);

  // Handle core tactile touch (visual & haptic feedback only)
  const handleCoreTouch = () => {
    setCorePress(true);
    sound.triggerHaptic('light');
    sound.playTap(false);
    setTimeout(() => setCorePress(false), 150);
  };

  const handleClaim = () => {
    if (!isClaimReady) return;
    sound.playClaim();
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#a855f7', '#fbbf24', '#06b6d4'],
    });
    onClaimDailyDrop(totalDailyDropAmount);
  };

  // Cooldown percentage
  const progressPercent = Math.min(100, Math.max(0, ((COOLDOWN_MS - msRemaining) / COOLDOWN_MS) * 100));

  return (
    <div className="flex flex-col items-center w-full max-w-2xl mx-auto px-4 py-2 sm:py-4 space-y-6">
      {/* Interactive Fullerene Core Orb (Visual & Tactile Only) */}
      <div className="relative w-60 h-60 sm:w-72 sm:h-72 flex items-center justify-center select-none my-2">
        <div className="absolute inset-0 rounded-full border border-purple-500/20 animate-spin-slow pointer-events-none" />
        <div className="absolute inset-4 rounded-full border border-dashed border-indigo-400/25 animate-spin-reverse pointer-events-none" />
        <div className="absolute inset-8 rounded-full bg-gradient-to-tr from-purple-900/30 via-fuchsia-900/20 to-indigo-950/30 blur-2xl pointer-events-none" />

        <div
          onClick={handleCoreTouch}
          className={`relative z-10 w-52 h-52 sm:w-64 sm:h-64 rounded-full cursor-pointer flex items-center justify-center transition-transform duration-100 touch-none ${
            corePress ? 'scale-95' : 'hover:scale-[1.02]'
          }`}
          title="CarbonDrop Fullerene Core"
        >
          <img
            src="/assets/aistudio/NeonLogo_bf9560f5.png"
            alt="Carbon Fullerene Core"
            className="w-full h-full object-contain filter drop-shadow-[0_0_30px_rgba(168,85,247,0.7)]"
            draggable={false}
          />
        </div>
      </div>

      {/* 24-Hour Daily Drop Claim Module with Countdown Timer & Generation Telemetry */}
      <div className="w-full glass-panel-elevated rounded-3xl p-5 sm:p-6 border border-purple-700/40 text-center relative overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 text-left">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white">24-Hour Daily Token Drop</h3>
              <span className="text-[11px] text-slate-400 font-mono">
                Automated isotope harvesting
              </span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-slate-400 uppercase font-mono block">Daily Target Quota</span>
            <span className="text-base sm:text-lg font-black font-mono text-amber-300 tabular-nums">
              +{totalDailyDropAmount.toLocaleString()} <span className="text-xs font-sans font-normal text-slate-400">$CARB</span>
            </span>
          </div>
        </div>

        {/* Claim or Countdown Display */}
        {isClaimReady ? (
          <div className="space-y-4">
            <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-600/40 text-emerald-300 text-xs font-semibold flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4.5 h-4.5 text-emerald-400 shrink-0" />
              <span>Full 24-hour quota of {totalDailyDropAmount.toLocaleString()} $CARB generated! Ready to claim!</span>
            </div>

            <button
              onClick={handleClaim}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-sm tracking-wide shadow-xl shadow-amber-500/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Coins className="w-5 h-5 fill-slate-950" />
              <span>Claim +{totalDailyDropAmount.toLocaleString()} $CARB Daily Drop</span>
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Real 24h Countdown Clock */}
            <div className="p-4 sm:p-5 rounded-2xl bg-black/60 border border-purple-900/40">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider block font-mono mb-3">
                Next Daily Drop Unlocks In
              </span>

              <div className="flex items-center justify-center gap-3">
                <div className="p-2 sm:p-2.5 rounded-xl bg-purple-950/80 border border-purple-800/40 min-w-[58px]">
                  <span className="font-mono text-2xl sm:text-3xl font-black text-white tabular-nums block">
                    {String(timeLeft.hours).padStart(2, '0')}
                  </span>
                  <span className="text-[9px] text-slate-400 uppercase font-mono">Hours</span>
                </div>

                <span className="text-2xl font-bold text-purple-400 font-mono">:</span>

                <div className="p-2 sm:p-2.5 rounded-xl bg-purple-950/80 border border-purple-800/40 min-w-[58px]">
                  <span className="font-mono text-2xl sm:text-3xl font-black text-white tabular-nums block">
                    {String(timeLeft.minutes).padStart(2, '0')}
                  </span>
                  <span className="text-[9px] text-slate-400 uppercase font-mono">Mins</span>
                </div>

                <span className="text-2xl font-bold text-purple-400 font-mono">:</span>

                <div className="p-2 sm:p-2.5 rounded-xl bg-purple-950/80 border border-purple-800/40 min-w-[58px]">
                  <span className="font-mono text-2xl sm:text-3xl font-black text-amber-300 tabular-nums block">
                    {String(timeLeft.seconds).padStart(2, '0')}
                  </span>
                  <span className="text-[9px] text-slate-400 uppercase font-mono">Secs</span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full h-2 rounded-full bg-slate-950 mt-4 overflow-hidden p-0.5 border border-purple-900/30">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-purple-500 via-fuchsia-500 to-amber-400 transition-all duration-1000"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>

              {/* Live Generation Metrics Display */}
              <div className="grid grid-cols-2 gap-2.5 mt-4 pt-3.5 border-t border-purple-900/40 text-left">
                <div className="p-2.5 rounded-xl bg-purple-950/40 border border-purple-800/30">
                  <span className="text-[10px] text-slate-400 font-mono uppercase block mb-0.5">Tokens Generated So Far</span>
                  <div className="flex items-baseline gap-1">
                    <span className="font-mono text-sm sm:text-base font-black text-amber-300 tabular-nums">
                      {tokensGeneratedSoFar.toLocaleString()}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">/ {totalDailyDropAmount.toLocaleString()}</span>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-purple-950/40 border border-purple-800/30">
                  <span className="text-[10px] text-slate-400 font-mono uppercase block mb-0.5">Live Generation Rate</span>
                  <div className="flex items-center gap-1.5">
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="font-mono text-sm sm:text-base font-black text-emerald-400 tabular-nums">
                      +{tokensPerHour} <span className="text-[10px] text-slate-400 font-sans font-normal">/ hr</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-400">
              Generating at <span className="font-mono text-amber-300 font-semibold">{tokensPerSecond} $CARB/sec</span>. Visit the <span className="text-purple-300 font-semibold">Boost</span> tab to upgrade your 30-day Mining Plan!
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
