/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { relations } from 'drizzle-orm';
import {
  pgTable,
  serial,
  text,
  doublePrecision,
  integer,
  bigint,
  boolean,
  timestamp,
} from 'drizzle-orm/pg-core';

// Users table (Telegram Miners)
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  telegramId: text('telegram_id').notNull().unique(),
  username: text('username').notNull(),
  balance: doublePrecision('balance').default(1250).notNull(),
  hashrate: doublePrecision('hashrate').default(3.5).notNull(),
  energy: integer('energy').default(1000).notNull(),
  maxEnergy: integer('max_energy').default(1000).notNull(),
  squadCount: integer('squad_count').default(0).notNull(),
  squadEarned: doublePrecision('squad_earned').default(0).notNull(),
  walletAddress: text('wallet_address'),
  walletName: text('wallet_name'),
  activePlanId: text('active_plan_id'),
  activePlanExpiresAt: bigint('active_plan_expires_at', { mode: 'number' }),
  lastDailyClaimTimestamp: bigint('last_daily_claim_timestamp', { mode: 'number' }),
  lastSavedTimestamp: bigint('last_saved_timestamp', { mode: 'number' }),
  status: text('status').default('active').notNull(), // active, frozen, whitelisted, banned
  referredBy: text('referred_by'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Miner Hardware Rigs table
export const minerRigs = pgTable('miner_rigs', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  rigId: text('rig_id').notNull(),
  level: integer('level').default(0).notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// User Quests table
export const userQuests = pgTable('user_quests', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  questId: text('quest_id').notNull(),
  status: text('status').default('unclaimed').notNull(), // pending, completed, claimed
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Protocol Economy & System Admin Configuration Table
export const adminConfigTable = pgTable('admin_config', {
  id: serial('id').primaryKey(),
  dailyBaseDropRate: integer('daily_base_drop_rate').default(1000).notNull(),
  globalHashMultiplier: doublePrecision('global_hash_multiplier').default(1.0).notNull(),
  tapPowerBase: integer('tap_power_base').default(2).notNull(),
  maintenanceMode: boolean('maintenance_mode').default(false).notNull(),
  maintenanceMessage: text('maintenance_message').default(
    'CarbonDrop network undergoing scheduled quantum core upgrade.'
  ).notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Relationships
export const usersRelations = relations(users, ({ many }) => ({
  rigs: many(minerRigs),
  quests: many(userQuests),
}));

export const minerRigsRelations = relations(minerRigs, ({ one }) => ({
  user: one(users, {
    fields: [minerRigs.userId],
    references: [users.id],
  }),
}));

export const userQuestsRelations = relations(userQuests, ({ one }) => ({
  user: one(users, {
    fields: [userQuests.userId],
    references: [users.id],
  }),
}));
